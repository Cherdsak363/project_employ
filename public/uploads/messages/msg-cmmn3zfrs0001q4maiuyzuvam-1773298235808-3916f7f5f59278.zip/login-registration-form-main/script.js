// Run the script only after the full HTML is loaded
document.addEventListener("DOMContentLoaded", () => {

// Main wrapper that contains both Sign In & Sign Up UI
const wrapper = document.querySelector(".auth-wrapper");

// Switch to Sign Up view
document.querySelectorAll(".go-signup").forEach((btn) => {
  btn.addEventListener("click", (e) => {
    e.preventDefault(); // Prevent page reload
    wrapper.classList.add("active"); // Show Sign Up form
  });
});

// Switch back to Sign In view
document.querySelectorAll(".go-signin").forEach((btn) => {
  btn.addEventListener("click", (e) => {
    e.preventDefault(); // Prevent page reload
    wrapper.classList.remove("active"); // Show Sign In form
  });
});

// Theme toggle button (Dark ↔ Light)
const toggleBtn = document.querySelector(".theme-toggle");

// Check if theme toggle exists (prevents JS errors)
if (toggleBtn) {
  const icon = toggleBtn.querySelector("i"); // Theme icon inside button

  toggleBtn.addEventListener("click", () => {
    // Toggle light theme on body
    document.body.classList.toggle("light");

    // Change icon based on active theme
    icon.className = document.body.classList.contains("light")
      ? "bi bi-sun-fill"       // Light mode icon
      : "bi bi-moon-stars-fill"; // Dark mode icon
  });
}

});
